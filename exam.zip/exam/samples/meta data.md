This is a badly named metadata file.

Please rename it properly.
